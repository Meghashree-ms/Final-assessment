export interface Registrationdetails {

        userName:string,
        userEmailId: string,
        userPhoneNumber:string,
        userDOB:string,
        gender:string,
        userPassword:string,

}

export interface ProductByName {

    
        productName:string,
        productType: string,
        productPrice:string,
        productQuantity:string,
        productAvailability:string,
        productRating:string,

    
}

import { ProductsByType } from './products-by-type.model';

describe('ProductsByType', () => {
  it('should create an instance', () => {
    expect(new ProductsByType()).toBeTruthy();
  });
});

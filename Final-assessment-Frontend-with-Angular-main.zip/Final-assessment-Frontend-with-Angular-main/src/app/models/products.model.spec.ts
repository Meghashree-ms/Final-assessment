import { Products } from './products.model';

describe('Products', () => {
  it('should create an instance', () => {
    expect(new Products()).toBeTruthy();
  });
});

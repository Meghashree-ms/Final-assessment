export interface Products {

    productName:string,
    productType: string,
    productPrice:string,
    productQuantity:string,
    productAvailability:string,
    productRating:string,
}

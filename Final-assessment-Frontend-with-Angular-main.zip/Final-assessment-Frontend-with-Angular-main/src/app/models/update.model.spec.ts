import { Update } from './update.model';

describe('Update', () => {
  it('should create an instance', () => {
    expect(new Update()).toBeTruthy();
  });
});

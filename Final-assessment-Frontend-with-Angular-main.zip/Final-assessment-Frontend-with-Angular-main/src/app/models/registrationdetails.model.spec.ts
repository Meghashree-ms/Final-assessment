import { Registrationdetails } from './registrationdetails.model';

describe('Registrationdetails', () => {
  it('should create an instance', () => {
    expect(new Registrationdetails()).toBeTruthy();
  });
});

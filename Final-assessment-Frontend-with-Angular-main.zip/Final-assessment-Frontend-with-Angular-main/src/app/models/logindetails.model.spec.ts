import { Logindetails } from './logindetails.model';

describe('Logindetails', () => {
  it('should create an instance', () => {
    expect(new Logindetails()).toBeTruthy();
  });
});

import { Delete } from './delete.model';

describe('Delete', () => {
  it('should create an instance', () => {
    expect(new Delete()).toBeTruthy();
  });
});

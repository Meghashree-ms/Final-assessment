import { ProductByName } from './product-by-name.model';

describe('ProductByName', () => {
  it('should create an instance', () => {
    expect(new ProductByName()).toBeTruthy();
  });
});

export class Delete {
}

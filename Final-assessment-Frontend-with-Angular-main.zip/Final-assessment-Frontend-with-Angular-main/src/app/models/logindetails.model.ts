export class Logindetails {
    userName:string;
    userPassword:string;
}
